package com.example.mytermproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class ViewHolder extends RecyclerView.ViewHolder {
    public TextView name;
    public TextView kcal;
    public TextView protein;
    public TextView carbs;
    public TextView fat;
    public TextView na;
    public ViewHolder(Context context, View itemView) {
        super(itemView);
        name=itemView.findViewById(R.id.nameText);
        kcal=itemView.findViewById(R.id.kcalText);
        carbs=itemView.findViewById(R.id.carbsText);
        protein=itemView.findViewById(R.id.proteinText);
        fat=itemView.findViewById(R.id.fatText);
        na=itemView.findViewById(R.id.naText);
    }
}
