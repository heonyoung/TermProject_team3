package com.example.mytermproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity
{
    public String readDay = null;
    public String str = null;
    public CalendarView calendarView;
    public Button changeBtn, del_Btn, save_Btn;
    public TextView daySummary;
    public EditText contextEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calendarView = findViewById(R.id.calendarView);
        changeBtn = findViewById(R.id.changeBtn);
        daySummary = findViewById(R.id.daySummaryText);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener()
        {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth)
            {
                changeBtn.setVisibility(View.VISIBLE);
                daySummary.setVisibility(view.VISIBLE);
                moveToDay(year, month, dayOfMonth);
            }
        });

    }
    public void moveToDay(int year,int month,int dayOfMonth){
        daySummary.setText("주간 총 칼로리 : 0kcal");
        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), dayPageActivity.class);
                intent.putExtra("message", String.format("%d / %d / %d", year, month + 1, dayOfMonth));
                startActivity(intent);

            }
        });
    }
    private  void createDatabase(String Name){

    }
}