package com.example.mytermproject;
public class Item {
    public String Name;
    public int kcal;
    public int carbs;
    public int protein;
    public int fat;
    public int nat;
    public Item(String n,int k,int c,int p,int f,int na){
        Name=n;
        kcal=k;
        carbs=c;
        protein=p;
        fat=f;
        nat=na;
    }
}
