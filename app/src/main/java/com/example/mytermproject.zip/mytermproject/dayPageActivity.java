package com.example.mytermproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class dayPageActivity extends AppCompatActivity {
    FoodData foodData = new FoodData(dayPageActivity.this, 1);
    String curDate;
    DBHelper dbHelper;
    String FOOD;
    int KCAL;
    String curTYPE;
    public Button morningBtn,lunchBtn,dinnerBtn,addBtn;
    public TextView myList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_page);
        curDate = intent.getStringExtra("message");
        TextView tv = (TextView) findViewById(R.id.date);
        tv.setText(curDate);
        morningBtn = findViewById(R.id.morningBtn);
        lunchBtn = findViewById(R.id.lunchBtn);
        dinnerBtn = findViewById(R.id.dinnerBtn);
        myList=findViewById(R.id.myList);
        addBtn = findViewById(R.id.addBtn);
        dbHelper = new DBHelper(dayPageActivity.this, 1);
        morningBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curTYPE = "morning";
                myList.setVisibility(View.VISIBLE);
                myList.setText(dbHelper.getResult(curDate,curTYPE));
            }
        });
        lunchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curTYPE = "lunch";
                myList.setVisibility(View.VISIBLE);
                myList.setText(dbHelper.getResult(curDate,curTYPE));
            }
        });
        dinnerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curTYPE = "dinner";
                myList.setVisibility(View.VISIBLE);
                myList.setText(dbHelper.getResult(curDate,curTYPE));
            }
        });
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(v.getContext(), SubActivity.class);
                startActivity(intent2);
            }
        });
    }
}
